import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../features/notes/presentation/providers/note_provider.dart';
import '../../features/notes/presentation/providers/remote_provider.dart';
import 'sync_manager.dart';

final connectivityProvider = Provider<Connectivity>((ref) {
  return Connectivity();
});

final syncManagerProvider = Provider<SyncManager>((ref) {
  return SyncManager(
    localDataSource: ref.read(noteLocalDataSourceProvider),
    remoteDataSource: ref.read(noteRemoteProvider),
    queueRepository: ref.read(syncQueueRepositoryProvider),
  );
});

final connectivityListenerProvider = Provider<void>((ref) {
  final connectivity = ref.read(connectivityProvider);

  connectivity.onConnectivityChanged.listen((result) async {
    if (result.contains(ConnectivityResult.mobile) ||
        result.contains(ConnectivityResult.wifi) ||
        result.contains(ConnectivityResult.ethernet)) {
      await ref.read(syncManagerProvider).sync();

      await ref.read(noteProvider.notifier).loadNotes();
    }
  });
});