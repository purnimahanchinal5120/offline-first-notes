import 'package:flutter/foundation.dart';

import '../../features/notes/data/datasources/local/note_local_datasource.dart';
import '../../features/notes/data/datasources/remote/note_remote_datasource.dart';
import '../../features/notes/data/models/note_model.dart';
import '../../features/notes/domain/entities/operation_type.dart';
import '../../features/notes/domain/repositories/sync_queue_repository.dart';

class SyncManager {
  final NoteLocalDataSource localDataSource;
  final NoteRemoteDataSource remoteDataSource;
  final SyncQueueRepository queueRepository;

  SyncManager({
    required this.localDataSource,
    required this.remoteDataSource,
    required this.queueRepository,
  });

  Future<void> sync() async {
    debugPrint("============== SYNC STARTED ==============");

    final operations = await queueRepository.getOperations();

    for (final operation in operations) {
      try {
        switch (operation.operation) {
          case OperationType.create:
            await _create(operation.noteId);
            break;

          case OperationType.update:
            await _update(operation.noteId);
            break;

          case OperationType.delete:
            await _delete(operation.noteId);
            break;
        }

        await queueRepository.removeOperation(
          operation.noteId,
        );
      } catch (e) {
        debugPrint(
          "Failed to sync ${operation.noteId}: $e",
        );
      }
    }

    await _downloadLatestNotes();

    debugPrint("============== SYNC FINISHED ==============");
  }

  Future<void> _create(String noteId) async {
    final note = await localDataSource.getNoteById(
      noteId,
    );

    if (note == null) return;

    final remote = await remoteDataSource.createNote(
      note,
    );

    await localDataSource.updateNote(
      NoteModel.fromEntity(
        note.copyWith(
          remoteId: remote.remoteId,
        ),
      ),
    );
  }

  Future<void> _update(String noteId) async {
    final note = await localDataSource.getNoteById(
      noteId,
    );

    if (note == null) return;

    if (note.remoteId == null) {
      await _create(noteId);
      return;
    }

    await remoteDataSource.updateNote(
      note,
    );
  }

  Future<void> _delete(String noteId) async {
    final note = await localDataSource.getNoteById(
      noteId,
    );

    if (note == null) return;

    if (note.remoteId == null) return;

    await remoteDataSource.deleteNote(
      note.remoteId!,
    );
  }

  Future<void> _downloadLatestNotes() async {
    final remoteNotes =
    await remoteDataSource.getNotes();

    final localNotes =
    await localDataSource.getNotes();

    for (final remote in remoteNotes) {
      final exists = localNotes.any(
            (e) => e.remoteId == remote.remoteId,
      );

      if (!exists) {
        await localDataSource.addNote(
          remote,
        );
      }
    }
  }
}