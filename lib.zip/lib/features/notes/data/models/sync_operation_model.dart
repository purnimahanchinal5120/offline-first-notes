import '../../domain/entities/operation_type.dart';

class SyncOperationModel {
  final String noteId;
  final OperationType operation;
  final DateTime createdAt;

  const SyncOperationModel({
    required this.noteId,
    required this.operation,
    required this.createdAt,
  });
}